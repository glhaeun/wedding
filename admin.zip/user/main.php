<?php

    include 'component/connect.php';
    include 'component/session.php';


    include 'OpeningCard.php';
    include 'bridegroom.php';
    ?>
    <!-- <div class="separator-landing"></div> -->
    <?php
    include 'location.php';
    ?>
    <!-- <div class="separator-landing"></div> -->
    <?php
    include 'timeline.php';
    ?>
    <!-- <div class="separator-landing"></div> -->
    <?php
    include 'rsvp.php';
    ?>
    <!-- <div class="separator-landing"></div> -->
    <?php
    include 'scratch.php';
    ?>
    <!-- <div class="separator-landing"></div> -->
    <?php
    include 'gifts.php';
    ?>
    <!-- <div class="separator-landing"></div> -->
    <?php
    include 'thankyou.php';
?>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script>

